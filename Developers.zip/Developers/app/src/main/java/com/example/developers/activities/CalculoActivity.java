package com.example.developers.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.developers.R;

public class CalculoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo);

        TextView txtImc = (TextView) findViewById(R.id.IMC);
        TextView txtMetabolismo = (TextView) findViewById(R.id.MB);
        Button volver = (Button) findViewById(R.id.volver);

        String mb = getIntent().getStringExtra("mb");
        String imc = getIntent().getStringExtra("imc");
        txtMetabolismo.setText("Metabolismo Basal: " + mb);
        txtImc.setText("IMC " + imc);

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}