package com.example.developers.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.developers.R;
import com.example.developers.model.Registro;
import com.example.developers.recycler.RegistroAdapter;

import java.util.ArrayList;

public class RegistrosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registros);
        Bundle bundle = getIntent().getExtras();
        ArrayList<Registro> registros = (ArrayList<Registro>) bundle.getSerializable("lista");
        RegistroAdapter adaptador = new RegistroAdapter(this, R.layout.registro_detalle, registros);
        RecyclerView listaContactos = (RecyclerView) findViewById(R.id.recyclerRegistros);
        listaContactos.setAdapter(adaptador);
        listaContactos.setLayoutManager(new LinearLayoutManager(this));
        listaContactos.setHasFixedSize(true);
    }
}