package com.example.developers.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class Registro implements Serializable {
    double peso;
    int edad;
    String genero;
    int estatura;
    double imc;
    double metabolismo;
    Date fechaRegistro;

    public Registro(double peso, int edad, String genero, int estatura, double imc, double metabolismo) {
        this.peso = peso;
        this.edad = edad;
        this.genero = genero;
        this.estatura = estatura;
        this.imc = imc;
        this.metabolismo = metabolismo;
        Calendar calendar = Calendar.getInstance();
        this.fechaRegistro = calendar.getTime();
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getEstatura() {
        return estatura;
    }

    public void setEstatura(int estatura) {
        this.estatura = estatura;
    }

    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        this.imc = imc;
    }

    public double getMetabolismo() {
        return metabolismo;
    }

    public void setMetabolismo(double metabolismo) {
        this.metabolismo = metabolismo;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
