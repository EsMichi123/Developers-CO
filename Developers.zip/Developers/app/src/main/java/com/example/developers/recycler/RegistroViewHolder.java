package com.example.developers.recycler;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.developers.R;

public class RegistroViewHolder extends RecyclerView.ViewHolder {

    private TextView txtDetallePeso;
    private TextView txtDetalleFecha;
    private TextView txtDetalleImc;
    private TextView txtDetalleMetabolismo;
    private TextView txtDetalleEdad;
    private TextView txtDetalleEstatura;
    private TextView txtDetalleGenero;


    public RegistroViewHolder(@NonNull View itemView) {
        super(itemView);
        txtDetallePeso = itemView.findViewById(R.id.txtDetallePeso);
        txtDetalleFecha = itemView.findViewById(R.id.txtDetalleFecha);
        txtDetalleImc = itemView.findViewById(R.id.txtDetalleImc);
        txtDetalleMetabolismo = itemView.findViewById(R.id.txtDetalleMetabolismo);
        txtDetalleEdad = itemView.findViewById(R.id.txtDetalleEdad);
        txtDetalleEstatura = itemView.findViewById(R.id.txtDetalleEstatura);
        txtDetalleGenero = itemView.findViewById(R.id.txtDetalleGenero);

    }

    public TextView getTxtDetallePeso() {
        return txtDetallePeso;
    }

    public void setTxtDetallePeso(TextView txtDetallePeso) {
        this.txtDetallePeso = txtDetallePeso;
    }

    public TextView getTxtDetalleFecha() {
        return txtDetalleFecha;
    }

    public void setTxtDetalleFecha(TextView txtDetalleFecha) {
        this.txtDetalleFecha = txtDetalleFecha;
    }

    public TextView getTxtDetalleImc() {
        return txtDetalleImc;
    }

    public void setTxtDetalleImc(TextView txtDetalleImc) {
        this.txtDetalleImc = txtDetalleImc;
    }

    public TextView getTxtDetalleMetabolismo() {
        return txtDetalleMetabolismo;
    }

    public void setTxtDetalleMetabolismo(TextView txtDetalleMetabolismo) {
        this.txtDetalleMetabolismo = txtDetalleMetabolismo;
    }

    public TextView getTxtDetalleEdad() {
        return txtDetalleEdad;
    }

    public void setTxtDetalleEdad(TextView txtDetalleEdad) {
        this.txtDetalleEdad = txtDetalleEdad;
    }

    public TextView getTxtDetalleEstatura() {
        return txtDetalleEstatura;
    }

    public void setTxtDetalleEstatura(TextView txtDetalleEstatura) {
        this.txtDetalleEstatura = txtDetalleEstatura;
    }

    public TextView getTxtDetalleGenero() {
        return txtDetalleGenero;
    }

    public void setTxtDetalleGenero(TextView txtDetalleGenero) {
        this.txtDetalleGenero = txtDetalleGenero;
    }
}
