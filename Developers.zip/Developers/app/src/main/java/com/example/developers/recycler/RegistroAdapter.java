package com.example.developers.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.developers.model.Registro;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class RegistroAdapter extends RecyclerView.Adapter<RegistroViewHolder> {
    Context context;
    int layout;
    List<Registro> lista;
    LayoutInflater inflater;

    public RegistroAdapter(Context context, int layout, List<Registro> lista) {
        this.context = context;
        this.layout = layout;
        this.lista = lista;
        this.inflater=LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public RegistroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = inflater.inflate(layout, parent, false);
        return new RegistroViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull RegistroViewHolder holder, int position) {
        Registro registro = lista.get(position);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String strDate = dateFormat. format(registro.getFechaRegistro());
        holder.getTxtDetallePeso().setText("Peso: "+ Double.toString(registro.getPeso())+" Kg");
        holder.getTxtDetalleFecha().setText(strDate);
        holder.getTxtDetalleEdad().setText("Edad: "+ Integer.toString(registro.getEdad())+" Años");
        holder.getTxtDetalleEstatura().setText("Estatura: "+ Integer.toString(registro.getEstatura())+" Cm");
        holder.getTxtDetalleMetabolismo().setText("Metabolismo: "+ String.format("%.1f",(registro.getMetabolismo())));
        holder.getTxtDetalleImc().setText("Imc:"+ String.format("%.1f",(registro.getImc())));
        holder.getTxtDetalleGenero().setText("Genero:"+(registro.getGenero()));
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }
}
