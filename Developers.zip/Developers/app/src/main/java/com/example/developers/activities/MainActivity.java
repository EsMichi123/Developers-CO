package com.example.developers.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.developers.R;
import com.example.developers.model.Registro;
import com.example.developers.recycler.RegistroAdapter;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<Registro> registros = new ArrayList<Registro>();
        TextView txtTitulo = findViewById(R.id.txtTitulo);
        Button btnCalculo = findViewById(R.id.btnCalculo);
        Button btnRegistros = findViewById(R.id.btnRegistros);
        EditText editEdad = findViewById(R.id.editEdad);
        EditText editPeso = findViewById(R.id.editPeso);
        EditText editEstatura = findViewById(R.id.editEstatura);
        RadioButton rbFemenino = findViewById(R.id.rbFemenino);
        btnCalculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double peso = Double.parseDouble(editPeso.getText().toString());
                int edad = Integer.parseInt(editEdad.getText().toString());
                int estatura = Integer.parseInt(editEstatura.getText().toString());
                boolean esFemenino = rbFemenino.isChecked();
                double metabolismo = 0;
                String genero;
                if (esFemenino==true) {
                    metabolismo = (10*peso)+(6.25*estatura)-(5*edad)-161;
                    genero = "Femenino";
                }
                else {
                    metabolismo = (10*peso)+(6.25*estatura)-(5*edad)+5;
                    genero = "Masculino";
                }
                double imc = peso/(estatura*estatura)*10000;
                String resultadoMb = String.format("%.1f",metabolismo);
                String resultadoImc = String.format("%.1f",imc);
                Registro registro = new Registro(peso,edad,genero,estatura,imc,metabolismo);
                registros.add(registro);
                Intent intentCalculo = new Intent(MainActivity.this, CalculoActivity.class);
                intentCalculo.putExtra("imc", resultadoImc);
                intentCalculo.putExtra("mb",resultadoMb);
                startActivity(intentCalculo);

            }
        });
        btnRegistros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (registros.isEmpty()){
                    Toast.makeText(getApplicationContext(),"No hay ningun registro anterior",Toast.LENGTH_LONG).show();
                } else {
                    Intent itemIntent = new Intent(MainActivity.this, RegistrosActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("lista", registros);
                    itemIntent.putExtras(bundle);
                    startActivity(itemIntent);
                }
            }
        });


    }
}